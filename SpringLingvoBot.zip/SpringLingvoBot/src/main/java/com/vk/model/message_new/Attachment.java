package com.vk.model.message_new;

public class Attachment {
}
