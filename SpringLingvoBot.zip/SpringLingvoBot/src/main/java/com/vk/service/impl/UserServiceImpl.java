package com.vk.service.impl;

public class UserServiceImpl {
}
