package com.vk.service;

public class MessageService {
}
