package com.vk.service.impl;

public class MessageServiceImpl {
}
